window.LD = window.LD || {};
LD.util = (function () {
    var empty = function (val) {
        if (val === null || val === undefined || val === '') {
            return true;
        }
        return false;
    };
    var intval = function (value, defaultValue) {
        var value = parseInt(value);
        if (isNaN(value)) value = defaultValue;
        return value;
    };
    var floatval = function (value, defaultValue) {
        var value = parseFloat(value);
        if (isNaN(value)) value = defaultValue;
        return value;
    };
    /**
     * 分隔字符串，并且返回int数组
     * @param array             要分隔的数组
     * @returns {Array}
     */
    var splitArrayToInt = function (array) {
        var arr = [];
        for (var i = 0; i < array.length; i++) {
            arr[i] = parseInt(array[i]);
        }
        return arr;
    };
    /**
     *
     * @param array
     * @param splitstr
     * @returns {Array}
     * @constructor
     */
    var SplitArrayToArray = function (array, splitstr) {
        var arr = [];
        var temp = [];
        for (var i = 0; i < array.length; i++) {
            temp = array[i].split(splitstr);
            arr[i] = Array(parseInt(temp[0]), temp[1]);
        }
        return arr;
    };
    var scrollTo = function (obj, toppx) {
        var idtop;
        idtop = obj.offset().top - toppx;
        $('body,html').animate({scrollTop: idtop}, 500);
    };
    return {
        empty: empty,
        splitArrayToInt: splitArrayToInt,
        SplitArrayToArray: SplitArrayToArray,
        scrollTo: scrollTo,
        intval: intval,
        floatval: floatval,
    }
})();

LD.tip = (function () {
    //弹出带按纽的提示层
    var alert = function (msg, callback, options) {
        var ico = LD.util.empty(options) || LD.util.empty(options.ico) ? 0 : options.ico;
        var title = LD.util.empty(options) || LD.util.empty(options.title) ? "温馨提示" : options.title;
        callback = $.isFunction(callback) ? callback : "";
        layer.alert(msg, {icon: ico, title: title, area: ['auto', 'auto']}, callback);
    };
    //弹出简单的提示框
    var msg = function (msg, callback, time) {
        time = LD.util.empty(time) ? 3000 : time;
        callback = $.isFunction(callback) ? callback : "";
        layer.msg(msg, {time: time}, callback);
    };
    var closeAll = function () {
        layer.closeAll();
    };
    //弹出错误警告
    var error = function (msg, callback) {
        alert(msg, callback, {title: '严重错误', ico: 2})
    };
    /**
     * 弹出带提示的对话框
     * @param msg       要提示的话语
     * @param callback  点击确定后的回调函数
     */
    var confirm = function (msg, callback) {
        layer.confirm(msg, {icon: 3, title: '请确认您的操作'}, callback)
    };
    var loading = function(msg){
        layer.msg(msg,{shade:[0.3, '#393D49'],time:0});
    };
    /**
     * 点击弹出隐藏层
     */
    var open = function (options) {
        layer.open(options);
    };
    /**
     * 显示图片
     */
    var showImages = function (imgurl) {
        layer.open({
            type: 1,
            content: '<img src="' + imgurl + '" />',
            title: false,
            closeBtn: 0,
            shadeClose: true,
            skin: 'layui-layer-nobg',
            area: ['auto', 'auto']
        });
    };
    //点击弹出框
    var ldIframe = function () {
        $(document).on('click', '.ld-iframe', function () {
            LD.tip.closeAll();
            var title = !$(this).attr('title') ? false : $(this).attr('title');
            var width = LD.util.empty($(this).data('width')) ? '65%' : $(this).data('width');
            var heightpx = $(window).height();
            var url = $(this).data('url');
            layer.open({
                type: 2,
                title: title,
                offset: 'r',
                area: [width, heightpx + 'px'],
                shadeClose: true,
                anim: 1,
                content: url
            });
            return false;
        })
    };
    //region手机操作
    var mobileSuccess = function (msg, timeOut, callBack) {
        var str = '<div class="mobile-success"><div class="weui-mask_transparent"></div><div class="weui-toast"><i class="weui-icon_toast toast_success"></i><p class="weui-toast__content">' + msg + '</p></div></div>';
        $('body').append(str);
        timeOut = LD.util.intval(timeOut, 1);
        var successStr = setInterval(function () {
            timeOut--;
            if (timeOut <= 0) {
                $('.mobile-success').remove();
                clearInterval(successStr);
                if ($.isFunction(callBack)) {
                    new callBack();
                }
            }
        }, 1000);
    };
    var mobileError = function (msg, timeOut, callBack) {

        var str = '<div class="mobile-error"><div class="weui-mask_transparent"></div><div class="weui-toast"><i class="weui-icon_toast toast_cancel"></i><p class="weui-toast__content">' + msg + '</p></div></div>';
        $('body').append(str);
        timeOut = LD.util.intval(timeOut, 1);
        var errorStr = setInterval(function () {
            timeOut--;
            if (timeOut <= 0) {
                $('.mobile-error').remove();
                clearInterval(errorStr);
            }
        }, 1000);
    };
    //endregion
    return {
      alert: alert,
      msg: msg,
      closeAll: closeAll,
      error: error,
      confirm: confirm,
      loading: loading,
      open: open,
      ldIframe: ldIframe,
      showImages: showImages,
      mobileSuccess: mobileSuccess,
      mobileError: mobileError,
    }
})();

//cookie
LD.cookie = (function () {
    var set = function (e, t, a) {
        e = 'zkeys' + e;
        var n = e + "=" + escape(t) + "; path=/";

        if (a > 0) {
            var r = new Date;
            r.setTime(r.getTime() + a * 3600 * 1e3);
            n = n + ";expires=" + r.toGMTString()
        }
        document.cookie = n

    };
    var get = function (e) {
        e = 'zkeys' + e;
        var t = document.cookie;
        var a = t.split("; ");
        for (var n = 0; n < a.length; n++) {
            var r = a[n].split("=");
            if (r[0] == e) return unescape(r[1])
        }
        return null
    };
    var del = function (e) {
        key = 'zkeys' + e;
        var t = new Date;
        t.setTime(t.getTime() - 1);
        var a = get(e);
        if (a != null) document.cookie = key + "=" + a + "; path=/;expires=" + t.toGMTString()
    };
    return {
        set: set,
        get: get,
        del: del,
    }
})();

LD.ajax = (function () {
    /**
     * POST提交数据，解决IE缓存，并且处理默认的错误事件和服务器错误事件
     * @param url         要提交的地址
     * @param data        要提交的数据，json数据
     * @param callback    成功后的回调函数，可以为空
     * @param options     其它参数，目前支持beforeSend和btnObj按纽
     */
    var post = function (url, data, callback, options, error) {
        var ajax = $.ajax({
            url: url, type: "post", cache: false, dataType: "json", data: data,
            beforeSend: function () {
                if (options && options.beforeSend) {
                    new options.beforeSend();
                }
            },
            success: function (data) {
                if (options && options.iframe == true) {
                    var windowObj = parent.window;
                    var layerObj = parent.LD;
                } else {
                    var windowObj = window;
                    var layerObj = LD;
                }
                if (data.status == 'y') {
                    if ($.isFunction(callback)) {
                        new callback(data);
                        return;
                    } else {
                        var ifrmae = options && options.iframe == true ? true : false;
                        if (LD.util.empty(data.info)) {
                            windowObj.location.href = data.url;
                        } else {
                            if (options && options.mobile) {
                                LD.tip.mobileSuccess(data.info, 1, function () {
                                    if (data.url == "") {
                                        windowObj.location.reload();
                                    } else {
                                        windowObj.location.href = data.url;
                                    }
                                });
                            } else {
                                layerObj.tip.alert(data.info, function () {
                                    layerObj.tip.closeAll();
                                    if (data.url == "") {
                                        windowObj.location.reload();
                                    } else {
                                        windowObj.location.href = data.url;
                                    }
                                }, {title: '操作成功', ico: 1});
                            }
                        }
                    }
                }
                else if (data.status == 'n') {
                    if ($.isFunction(error)) {
                        new error(data);
                        return;
                    } else {
                        if (options && options.mobile) {
                            LD.tip.mobileError(data.info);
                        } else {
                            if (!LD.util.empty(data.url)) {
                                windowObj.location.href = data.url;
                            }
                            layerObj.tip.alert(data.info);
                        }
                    }
                }
                else if (data.status == 'jump') {
                  windowObj.location.href = data.url;
                }
                else if (data.status == 'func') {
                  var func = eval(data.url);
                  new func(data.info);
                }
                else {
                    if (options && options.mobile) {
                        LD.tip.mobileError(data.info);
                    } else {
                        layerObj.tip.msg(data.info, function () {
                            if (!LD.util.empty(data.url)) {
                                windowObj.location.href = data.url;
                            }
                        });
                    }
                }
                if (data.status != 'y') {
                    if (options && options.btnObj) {
                        __aformFail(options.btnObj);
                    }
                }
            },
            error: function (jqXHR, textStatus, errorThrown) {
                LD.tip.error("严重错误：服务器运行错误");
                if (options && options.btnObj) {
                    __aformFail(options.btnObj);
                }
            }
        });

        function __aformFail(btnObj) {
            btnObj.attr("disabled", false).removeClass('disabled').val('再次提交');
        }

        return ajax
    };
    //点击ajax提交
    var clickUrl = function () {
      $(document).on('click', '.ld-ajax-url', function () {
        var url = $(this).data('url');
        var content = $(this).data('content');
        var that = $(this);
        //如果没传提示框，则直接提交ajax
        LD.tip.loading('正在提交，请稍等');
        if (LD.util.empty(content)) {
          post(url);
        } else {
          content += "<br />您确定要继续吗？";
          LD.tip.confirm(content, function () {
            LD.tip.closeAll();
            post(url);
            });
          }
      });
    };
    return {
        post: post,
        clickUrl: clickUrl,
    };
})();

//表单处理
LD.validater = (function () {

    var tiptype = 1;
    /**
     * 表单验证初始化
     * @param option
     */
    var initValidate = function (options) {
        var settings = $.extend(true, {formObj: '.ld-form', btnObj: '.ld-btn', success: '',}, options);
        var $_formObj = $(settings.formObj);
        var $_btnObj = $(settings.btnObj);
        tiptype = $_formObj.data('tiptype') ? $_formObj.data('tiptype') : 1;
        var iframe = $_formObj.data('iframe') ? true : false;
        var optionSuccess = settings.success;
        $_formObj.find("[data-regex]").each(function () {
            checkInput($(this));
        });
        $_btnObj.unbind().click(function () {
            $_formObj = $(this).parents('.ld-form');
            var flag = true;
            var that = $(this);
            $_formObj.find("[data-regex]").each(function () {
                //如果最上级的div被隐藏了。代表不需要判断
                if ($(this).parents().is(':hidden') === false) {
                    if ($(this).data('success') !== true) {
                        $(this).trigger('change');
                        if (!$(this).hasClass('Validform_success')) {
                            flag = false;
                        }
                    }
                }
            });
            if (flag) {
                var url = $(this).data('actionurl') ? $(this).data('actionurl') : $_formObj.attr('action');
                var callback = '';
                if ($_formObj.data('success')) {
                    callback = eval($_formObj.data('success'));
                }
                var mobile = !LD.util.empty(options) && options.mobile ? options.mobile : false;
                LD.ajax.post(url, $_formObj.serialize(), callback, {
                    beforeSend: function () {
                        that.attr('disabled', true).addClass('disabled').val('正在提交');
                    },
                    btnObj: that,
                    iframe: iframe,
                    mobile: mobile,
                })
            }
            return false;
        })
    };
    //某个表单正确的时候，可以调用此方法在旁边赋值
    var successMsg = function (obj, successMsg) {
        if (typeof(successMsg) == "undefined") successMsg = '';
        LD.validater.getNextObj(obj).html(successMsg + addStr).attr('class', '').addClass(successClass);
        obj.removeClass(errorClass).addClass(successClass)
    };
    //某个表单错误的时候，可以调用此方法在旁边赋值
    var errorMsg = function (obj, errorMsg) {
        if (typeof(errorMsg) == "undefined") errorMsg = '';
        LD.validater.getNextObj(obj).html(errorMsg + addStr).attr('class', '').addClass(errorClass);
        obj.removeClass(successClass).addClass(errorClass)
    };
    //表单触发和表单提交共用方法
    var checkInput = function (obj) {
        var regex = obj.data('regex');
        var tipStr = obj.attr('placeholder');  //要提示的值
        if (regex) {
            var nextObj = LD.validater.getNextObj(obj);
            obj.click(function () {
                if (obj.val().length == 0) {
                    var tipmsg = obj.data('nullmsg');
                    if (tipmsg) nextObj.html(tipmsg).addClass('validform-tip');
                }
            });
            if (regex != 'custom') {
                obj.bind('input propertychange change', function () {
                    var value = obj.val(), className = '';
                    if (LD.regex.fromRegex(regex, value)) {
                        obj.addClass('Validform_success').removeClass('Validform_error');
                        nextObj.html('').attr('class', '').addClass('Validform_checktip Validform_right');
                    } else {
                        var lderrormsg = obj.data('errormsg');
                        obj.addClass('Validform_error');
                        if (lderrormsg == false) {
                            nextObj.attr('class', '').addClass('Validform_checktip Validform_wrong');
                        } else {
                            if (lderrormsg) tipStr = lderrormsg;
                            if (LD.util.empty(tipStr)) tipStr = '此项内容不能为空';  //如果还是未获取到错误的提示字符串
                            nextObj.html(tipStr).attr('class', '').addClass('Validform_checktip Validform_wrong');
                        }
                    }
                });
                //如果为ajax请求
                if (obj.data('ajaxurl')) {
                    var changeType = 'blur';
                    if (obj.data('ajaxtype')) {
                        changeType = obj.data('ajaxtype')
                    }
                    obj.bind(changeType, function () {
                        var url = obj.data('ajaxurl');
                        var ajaxCustom = $(this).data('ajaxcustom');
                        LD.ajax.post(url, {'param': $(this).val()}, function (data) {
                            nextObj.html(data.info).attr('class', '').addClass('Validform_checktip Validform_right');
                        }, {
                            beforeSend: function () {
                                nextObj.html('正在检测信息...').removeClass('Validform_wrong Validform_right').addClass('Validform_loading');
                            }
                        }, function (data) {
                            obj.removeClass('Validform_success').addClass('Validform_error');
                            nextObj.html(data.info).attr('class', '').addClass('Validform_checktip Validform_wrong');
                        });
                    })
                }
                //ajax检测结束
            }
        }
    };
    var getNextObj = function (obj) {
        if (tiptype == 2) {
            return obj.data('tipid') ? $('#' + obj.data('tipid')) : obj.parent().parent().parent().find('.msg-tip').last();
        } else {
            return obj.data('tipid') ? $('#' + obj.data('tipid')) : obj.parent().find('span').last();
        }
    };
    return {
        initValidate: initValidate,
        successMsg: successMsg,
        errorMsg: errorMsg,
        getNextObj: getNextObj,
    };
})();

//初始化组件
LD.component = (function () {
    /**
     * @method initDropDown 初始化下拉组件
     * 固定结构：
     *        2.容器需要绑定data-field_name，用于指定需要填写的表单域
     * @param options {Object} 配置项
     * @param options.containerSelector {string} 容器选择器，指定需要填写的表单
     *
     * @example 一些栗子
     * // 默认配置：
     LD.component.initDropDown();
     // 自定义配置：
     LD.component.initDropDown({
			selectMain: ".drop-container",
		});
     */
    var initDropDown = function (options) {
        var settings = $.extend(true, {
            selectMain: ".form-select",
        }, options);
        var $_selectMain = $(settings.selectMain);
        $_selectMain.on('mousedown', 'li', function () {
            var ul = $(this).parent();
            var obj = $(this).parent().parent();
            obj.find('cite').html($(this).html());
            $(this).siblings().removeClass('active');
            $(this).addClass('active');
            var inputid = ul.data('inputid');
            var inputObj = inputid == undefined ? obj.find('input:hidden') : $('#' + inputid);
            inputObj.val($(this).data('value')).trigger('change');
            ul.hide();
        });
        //开始循环
        $_selectMain.on('click', 'cite', function () {
            var obj = $(this).parents('.form-select');
            var menuObj = obj.find('ul');
            if (obj.hasClass('disabled')) return false;
            if (menuObj.is(':hidden')) {
                menuObj.show();
                $(this).addClass('cart-up');
            } else {
                menuObj.hide();
                $(this).removeClass('cart-up');
            }
        });
        $_selectMain.on('blur', 'cite', function () {
            $(this).parents('.form-select').find('ul').hide();
            $(this).removeClass('cart-up');
        });
        $_selectMain.each(function () {
            var menuObj = $(this).find('ul');
            var citeObj = $(this).find('cite');
            // citeObj.attr('tabindex','-1').css('outline','none').blur(function () {
            //   menuObj.hide();
            //   $(this).removeClass('cart-up');
            // });
            citeObj.attr('tabindex', '-1').css('outline', 'none');
            //默认赋值
            LD.component.initDropDownSetData({
                'menuObj': menuObj,
                'citeObj': citeObj,
            });
        });
    };
    /**
     * 下拉菜单赋值
     * @param option
     */
    var initDropDownSetData = function (option) {
        var $_menuObj = $(option.menuObj);
        var $_inputidObj = $('#' + $_menuObj.data('inputid'));
        var $_citeObj = $(option.citeObj);
        //初始化值
        var activeObj = $_menuObj.find('.active');
        if (activeObj.length == 0) {
            activeObj = $_menuObj.find('li').eq(0);
            activeObj.addClass('active');
        }
        var value = activeObj.data('value');
        var text = activeObj.html();
        $_inputidObj.val(value).trigger('change');
        $_citeObj.html(text);
    };
    //全选、反选、取消
    var selectAll = function () {
        $('.ld-select').each(function () {
            var classname = $(this).data('classname');
            $(this).find('.checkall').unbind().bind('click', function () {
                $("." + classname + " :checkbox").prop("checked", true);
            });
            $(this).find('.nocheckall').unbind().click(function () {
                $("." + classname + " :checkbox").each(function () {
                    $(this).prop("checked", !$(this).prop("checked"));
                });
            });
            $(this).find('.cancel').unbind().click(function () {
                $("." + classname + " :checkbox").prop("checked", false);
            });
        })
    };
    //Datatables表单初始化
    var tableList = function (datatableid) {
        var obj = LD.util.empty(datatableid) ? $("#datatable") : $("#" + datatableid);
        if (obj.length <= 0) return;
        //先处理分页
        var tableObj = obj.parents('.ld-table-container');
        var pageStr = '<div class="ld-page"><div class="ld-page-total">共0条</div><ul class="ld-page-num"></ul><select class="ld-page-select">';
        var pageArray = [10, 20, 30, 40, 50];
        $.each(pageArray, function (k, v) {
            var selected = k === 0 ? 'selected' : '';
            pageStr += '<option value="' + v + '" ' + selected + '>' + v + ' 条/页</option>';
        });
        pageStr += '</select><div class="ld-page-options">跳至 <input type="text">页</div></div>';
        tableObj.append(pageStr);
        var currentPage = 1
        if (tableObj.find('.ld-page-item-active').length > 0) currentPage = parseInt(tableObj.find('.ld-page-item-active').html());  //当前页
        var params = {currentPage: currentPage}

        ajaxGetDatatable(obj, params);
        //分页下拉菜单
        tableObj.find('.ld-page').on('change', '.ld-page-select', function () {
            params.currentPage = 1
            ajaxGetDatatable(obj, params);
        });
        //点击数字
        tableObj.find('.ld-page').on('click', '.ld-page-item', function () {
            params.currentPage = parseInt($(this).html());
            ajaxGetDatatable(obj, params);
        });
        //手动输入确定页面
        tableObj.find('.ld-page').on('keyup', 'input', function (event) {
            if (event.keyCode === 13) {
                params.currentPage = parseInt($(this).val())
                var maxPage = parseInt(tableObj.find('.ld-page-item').last().html())
                var minPage = parseInt(tableObj.find('.ld-page-item').first().html())
                if (params.currentPage > maxPage || params.currentPage < minPage) params.currentPage = 1
                ajaxGetDatatable(obj, params);
            }
        });
        //箭头点击
        tableObj.find('.ld-page').on('click', '.ld-page-prev', function () {
            params.currentPage--
            ajaxGetDatatable(obj, params);
        });
        tableObj.find('.ld-page').on('click', '.ld-page-next', function () {
            params.currentPage++
            ajaxGetDatatable(obj, params);
        });
        //表头点击
        obj.on('click', '.filter-icon', function () {
            var field = $(this).parents('th').data('field');
            if (field.indexOf(',') > 0) {
                field = field.split(',')
            }
            $(this).hasClass('filter-desc') ? $(this).removeClass('filter-desc').addClass('filter-asc') : $(this).removeClass('filter-asc').addClass('filter-desc');
            obj.find('.filter-icon').not($(this)).removeClass('filter-desc').removeClass('filter-asc')
            var dir = $(this).hasClass('filter-desc') ? 'desc' : 'asc'
            var order = []
            if (Array.isArray(field)) {
                $.each(field, function (k, v) {
                    order.push({name: v, dir: dir})
                })
            } else {
                order.push({name: field, dir: dir})
            }
            params.currentPage = 1
            params = $.extend(params, {order: order})
            ajaxGetDatatable(obj, params);
        })
    };
    //子方法加载数据
    var ajaxGetDatatable = function (obj, params) {
        var tableObj = obj.parents('.ld-table-container');
        layer.msg('数据加载中');
        var url = obj.data('url');
        var pagenum = parseInt(tableObj.find('.ld-page-select').val());  //每页显示多少条
        var currentPage = parseInt(params.currentPage)     //当前页
        var start = (currentPage - 1) * pagenum + 1
        params = $.extend(params, {start: start, length: pagenum})
        if (!params.order) params.order = []
        params.order = params.order.concat([{name: 'id', dir: 'desc'}])
        LD.ajax.post(url, params, function (data) {
            var str = '';
            $.each(data.data, function (k, v) {
                str += '<tr>';
                $.each(v, function (kk, vv) {
                    if (vv == null) vv = '';
                    str += '<td>' + vv + '</td>';
                })
                str += '</tr>';
            });
            if (LD.util.empty(str)) {
                str = '<div class="ld-table-no-data">数据库无记录</div>';
                obj.find('tbody').html('')
                tableObj.find('.ld-table-no-data').remove()
                tableObj.find('.ld-page').hide()
                tableObj.append(str)
            } else {
                tableObj.find('.ld-table-no-data').remove()
                tableObj.find('.ld-page').show()
                obj.find('tbody').html(str);
            }
            layer.closeAll();
            //处理分页
            var total = data.recordsTotal;
            tableObj.find('.ld-page-total').html('共 ' + total + ' 条');
            var pageTotal = Math.ceil(total / pagenum); //总共多少页
            var pageStr = '<li class="ld-page-prev"></li>';
            if (pageTotal >= 10) {
                if (currentPage > pageTotal - 4) {
                    for (var i = 1; i <= pageTotal; i++) {
                        if (i === 1) {
                            pageStr += '<li class="ld-page-item">' + i + '</li>'
                        } else if (i === 2) {
                            pageStr += '<li class="ld-page-item-omit disabled">...</li>'
                        } else if (i > pageTotal - 7) {
                            pageStr += i === currentPage ? '<li class="ld-page-item ld-page-item-active">' + i + '</li>' : '<li class="ld-page-item">' + i + '</li>'
                        }
                    }
                } else if (currentPage < 5) {
                    for (var i = 1; i <= pageTotal; i++) {
                        if (i <= 7) {
                            pageStr += i === currentPage ? '<li class="ld-page-item ld-page-item-active">' + i + '</li>' : '<li class="ld-page-item">' + i + '</li>'
                        } else if (i === 8) {
                            pageStr += '<li class="ld-page-item-omit disabled">...</li>'
                        } else if (i === pageTotal) {
                            pageStr += '<li class="ld-page-item">' + i + '</li>'
                        }
                    }
                } else {
                    for (var i = 1; i <= pageTotal; i++) {
                        if (i === 1 || i === pageTotal) {
                            pageStr += '<li class="ld-page-item">' + i + '</li>'
                        } else if (i === 2 || i === pageTotal - 1) {
                            pageStr += '<li class="ld-page-item-omit disabled">...</li>'
                        } else if (i >= currentPage - 2 && i <= currentPage + 2) {
                            pageStr += i === currentPage ? '<li class="ld-page-item ld-page-item-active">' + i + '</li>' : '<li class="ld-page-item">' + i + '</li>'
                        }
                    }
                }
            } else {
                for (var i = 1; i <= pageTotal; i++) {
                    pageStr += i === currentPage ? '<li class="ld-page-item ld-page-item-active">' + i + '</li>' : '<li class="ld-page-item">' + i + '</li>'
                }
            }
            pageStr += '<li class="ld-page-next"></li>'
            tableObj.find('.ld-page-num').html(pageStr)
            //如果当前页小于等于1,锁住左侧的箭头
            if (currentPage <= 1) {
                tableObj.find('.ld-page-prev').addClass('disabled');
            } else {
                tableObj.find('.ld-page-prev').removeClass('disabled');
            }
            //如果当前页大于等于共多少页,锁住右侧的箭头
            if (currentPage >= pageTotal) {
                tableObj.find('.ld-page-next').addClass('disabled');
            } else {
                tableObj.find('.ld-page-next').removeClass('disabled');
            }
        });
    }
    var ldIframe = function () {
        $(document).on('click', '.ld-iframe', function () {
            LD.tip.closeAll();
            var title = !$(this).attr('title') ? false : $(this).attr('title');
            var width = LD.util.empty($(this).data('width')) ? 'auto' : $(this).data('width');
            var height = LD.util.empty($(this).data('height')) ? 'auto' : $(this).data('height');
            var url = $(this).data('url');
            var offset = !$(this).data('offset') ? 'auto' : $(this).data('offset');
            layer.open({
                type: 2,
                title: title,
                offset: offset,
                area: [width, height],
                shadeClose: true,
                anim: 1,
                content: url
            })
            return false;
        })
    }
    return {
        initDropDown: initDropDown,
        initDropDownSetData: initDropDownSetData,
        selectAll: selectAll,
        tableList: tableList,
        ldIframe: ldIframe,
        ajaxGetDatatable: ajaxGetDatatable
    }
})();
//上传
LD.upload = (function () {
    var initialize = function () {
        //初始化所有图片的鼠标放上去显示删除和查看
        $('.upload-pic li img').each(function () {
            $(this).after(getDisplayDeleteStr());
        });
        imageMouse();
        //图片上传
        $('.ld-upload-thumb').each(function (k, v) {
            var id = $(this).attr('id');
            var size = !$(this).data('size') ? '200mb' : $(this).data('size');
            var filters = {
                mime_types: [ //只允许上传图片和zip文件
                    {title: "图片文件", extensions: "jpg,png,jpeg,zip"},
                ],
                max_file_size: size, //最大只能上传400kb的文件
            };
            var formName = $(this).data('form-name');
            var multi_selection = $(this).data('type') == 'imageFig' ? true : false;
            var options = {
                id: $(this).attr('id'),
                filters: filters,
                multi_selection: multi_selection,
                successCallBack: function (obj, data) {
                    var successObj = obj.parent().find('.upload-pic');
                    successObj.css('margin-bottom', '10px');
                    successObj.find('.progress').remove();
                    var str = getDisplayDeleteStr();
                    if (multi_selection) {
                        successObj.append('<li><img src="' + data.info + '" /><input type="hidden" name="' + formName + '[]" value="' + data.info + '"/>' + str + '</li>');
                    } else {
                        successObj.html('<li><img src="' + data.info + '" /><input type="hidden" name="' + formName + '" value="' + data.info + '"/>' + str + '</li>');
                    }
                }
            };
            initUpload(options);
        });
    };
    //图片时，鼠标放上去删除和查看的html代码
    var getDisplayDeleteStr = function () {
        var str = '<div class="file-panel"><i class="fa-trash-o" style="display: none;"></i><i class="fa-search-plus" style="display: none;"></i></div>';
        return str;
    };
    //鼠标滑过图片的事件
    var imageMouse = function () {
        $('.upload-pic').on('mouseenter', 'li', function () {
            $(this).find('.file-panel').css({height: 30}).find('i').show();
        });
        $('.upload-pic').on('mouseleave', 'li', function () {
            $(this).find('.file-panel').css({height: 0}).find('i').hide();
        });
        //删除图片
        $('.upload-pic').on('click', '.fa-trash-o', function () {
            var obj = $(this);
            LD.tip.confirm('您确定要删除此图片吗', function () {
                LD.tip.closeAll();
                obj.parents('li').remove();
            });
        });
        //查看图片
        $('.upload-pic').on('click', '.fa-search-plus', function () {
            var imgUrl = $(this).parents('li').find('img').attr('src');
            LD.tip.showImages(imgUrl);
        })
    };
    var locationurl = window.location.href;
    locationurl = locationurl.split("/");
    if (locationurl.length == 4) {
        locationurl = "index/index/uploadfile";
    } else if (locationurl.length > 4 && locationurl.length < 6) {
        locationurl = locationurl[3] + "/index/uploadfile";
    } else {
        locationurl = locationurl[3] + "/" + locationurl[4] + "/uploadfile";
    }
    //初始化上传组件
    var initUpload = function (options) {
        var browse_button = options.id;
        var size = options.size;
        var successCallBack = options.successCallBack;
        var uploader = new plupload.Uploader({
            runtimes: 'html5,flash,silverlight,html4',
            browse_button: browse_button,
            url: '/' + locationurl,
            file_data_name: 'file',
            multi_selection: options.multi_selection,
            flash_swf_url: "../../../static/js/plugin/plupload/Moxie.swf" ,
            filters: options.filters,
            init: {
                FilesAdded: function (up, file) {
                    var obj = $(up.settings.browse_button[0]);
                    obj.attr('disabled', true).val('正在上传');
                    uploader.start();
                },
                UploadProgress: function (up, file) {	//进度条
                    var percent = file.percent;
                    var obj = $(up.settings.browse_button[0]);
                    obj.parent().find('.progress').show().html("<div class='progress-bar  progress-bar-success progress-bar-striped' role='progressbar'style='width: " + percent + "%;'>" + percent + "%</div>");
                },
                FileUploaded: function (up, b, data) {
                    var obj = $(up.settings.browse_button[0]);
                    obj.parent().find('.progress').html('').hide();
                    obj.attr('disabled', false).val('上传文件');
                    var data = $.parseJSON(data.response);
                    if (data.status == 'y') {
                        new successCallBack(obj, data);
                        return false;
                    } else {
                        LD.tip.alert(data.info);
                    }
                },
                Error: function (up, err) {
                    var obj = $(up.settings.browse_button[0]);
                    obj.parent().find('.progress').html('').hide();
                    obj.attr('disabled', false).val('上传文件');
                    if (err.code == -602) {
                        LD.tip.alert('不能重复上传同一张图片');
                        return false;
                    }
                    if (err.message == 'File size error.') {
                        LD.tip.alert('文件大小超出上限');
                    } else {
                        if (err.status !== 200) {
                            LD.tip.error("上传服务器异常，请联系我们!");
                        }
                    }
                }
            }
        });
        uploader.init();
    };

    return {
        initialize: initialize,
    }
})();

LD.regex = {
    //判断域名
    domain: function (str) {
        regexStr = '^[\u4e00-\u9fa5A-Za-z0-9\-]+$';
        return LD.regex.test(regexStr, str);
    },
    //判断英文域名
    endomain: function (str) {
        regexStr = '^[A-Za-z0-9\-]+$';
        return LD.regex.test(regexStr, str);
    },
    //判断数字（含小数）
    n: function (str) {
        regexStr = '^[0-9]+.?[0-9]*$';
        return LD.regex.test(regexStr, str);
    },
    //判断是否为整数
    d: function (str) {
        regexStr = '^-?\\d+$';
        return LD.regex.test(regexStr, str);
    },
    //判断字母、数字
    name: function (str) {
        regexStr = '^[A-Za-z0-9_]+$';
        return LD.regex.test(regexStr, str);
    },
    //判断手机号
    mobile: function (str) {
        regexStr = '^0?(13|15|18|14|17)[0-9]{9}$';
        return LD.regex.test(regexStr, str);
    },
    //判断身份证号
    idcard: function (str) {
        // regexStr = '(^\d{15}$)|(^\d{18}$)|(^\d{17}(\d|X|x)$)';
        regexStr = '^[1-9]\\d{5}(18|19|([23]\\d))\\d{2}((0[1-9])|(10|11|12))(([0-2][1-9])|10|20|30|31)\\d{3}[0-9Xx]$';//18位
        regexStr1 = '^[1-9]\\d{5}\\d{2}((0[1-9])|(10|11|12))(([0-2][1-9])|10|20|30|31)\\d{2}$';//15位
        return LD.regex.test(regexStr, str) || LD.regex.test(regexStr1, str);
    },
    //判断中文
    zh: function (str) {
        regexStr = '^[\u4e00-\u9fa5\s?]+$';
        return LD.regex.test(regexStr, str);
    },
    //判断公司名称
    companyname: function (str) {
        regexStr = /^[A-Za-z0-9_()（）\-\u4e00-\u9fa5]+$/;
        return LD.regex.test(regexStr, str);
    },
    //判断图片格式
    picture: function (str) {
        regexStr = '^(.*)\.(jpg|bmp|gif|ico|pcx|jpeg|tif|png|raw|tga)$';
        return LD.regex.test(regexStr, str);
    },
    //判断只允许字母、数字、下划线
    username: function (str) {
        regexStr = '^[A-Za-z0-9_]+$';
        return LD.regex.test(regexStr, str);
    },
    //判断统一信用码
    creditcode: function (str) {
        regexStr = '/[^_IOZSVa-z\\W]{2}\\d{6}[^_IOZSVa-z\\W]{10}$/g';
        return LD.regex.test(regexStr, str);
    },
    //判断详细地址，支持字母数字下划线括号#号
    address: function (str) {
        regexStr = /^[A-Za-z0-9_()（）\#\-\u4e00-\u9fa5]+$/;
        return LD.regex.test(regexStr, str);
    },
    //判断邮箱地址
    email: function (str) {
        regexStr = '^[a-zA-Z0-9_-]+@[a-zA-Z0-9_-]+(\.[a-zA-Z0-9_-]+)+$';
        return LD.regex.test(regexStr, str);
    },
    //支持字母数字下划线空格
    wspace: function (str) {
        regexStr = '^[a-zA-Z0-9_\\s]+$';
        return LD.regex.test(regexStr, str);
    },
    test: function (regexStr, value) {
        var patt1 = new RegExp(regexStr);
        return patt1.test(value);
    },
    fromRegex: function (regexStr, value) {
        switch (regexStr) {
            case 'd':
                return LD.regex.d(value);
                break;
            case '*':
                return !LD.util.empty(value);
                break;
            case 'name':
                return LD.regex.name(value);
                break;
            case 'mobile':
                return LD.regex.mobile(value);
                break;
            case 'idcard':
                return LD.regex.idcard(value);
                break;
            case 'companyname':
                return LD.regex.companyname(value);
                break;
            case 'creditcode':
                return LD.regex.creditcode(value);
                break;
            case 'zh':
                return LD.regex.zh(value);
                break;
            case 'picture':
                return LD.regex.picture(value);
                break;
            case 'username':
                return LD.regex.username(value);
                break;
            case 'address':
                return LD.regex.address(value);
                break;
            case 'email':
                return LD.regex.email(value);
                break;
            case 'wspace':
                return LD.regex.wspace(value);
                break;
        }
    }
};
//正则表达式
// LD.regex = function (regStr, value) {
//   var regexStr = '';
//   switch (regStr) {
//     case 'intege1'://正整数
//       regexStr = '^[0-9]*[1-9][0-9]*$';
//       break;
//     case '*'://任意字符
//       return value.length > 0;
//       break;
//     case 'mobile'://手机号码
//       regexStr = '^0?(13|15|18|14|17|19)[0-9]{9}$';
//       break;
//     case 'address'://通信地址
//       regexStr = '^[A-Za-z0-9_()（）\#\-\u4e00-\u9fa5]*$';
//       break;
//     case 'companyname'://公司名称
//       regexStr = '^[A-Za-z0-9_()（）\-\u4e00-\u9fa5]*$';
//       break;
//     case 'email'://公司名称
//       regexStr = '^[a-zA-Z0-9_-]+@[a-zA-Z0-9_-]+(\.[a-zA-Z0-9_-]+)+$';
//       break;
//     case 'domain'://域名
//       regexStr = '^[\u4e00-\u9fa5A-Za-z0-9\-]+$';
//     break;
//   }
//   if (value.length <= 0) return false;
//   var patt1 = new RegExp(regexStr);
//   return patt1.test(value);
// };
