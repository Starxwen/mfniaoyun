$(function(){
	// topbar右角用户信息展示
	var API_HOST = "/";
	var paramString = "m=api&c=user&a=status";
	window.getUserInfo = function () {
		$.ajax({
			url: API_HOST,
			data: paramString,
			type: "GET",
			dataType: "json",
			success: function (responseData) {
				if (responseData.status) {
					$(".top-user-info-2").addClass("hide");
					$(".top-user-info-1").removeClass("hide").find(".member").html(responseData.name);
				}
			}
		});
	}
	// getUserInfo();

    if (sessionStorage.getItem("nav")){
      $('.nav_li').removeClass("active");
      index=sessionStorage.getItem("nav");
      $('.nav_li').eq(index).addClass("active");
    } else {
      $('.nav_li').eq(0).addClass("active");
    }
     $('.nav_li').click(function () {
       sessionStorage.setItem('nav', $(this).index());
     });

      /*导航下拉*/
      // $(".head-nav .nav-list li").hover(function () {
      //    $(this).find('.pop-list').show();
      // }, function () {
      //    $(this).find('.pop-list').hide();
      // });

      $(".head-nav .nav-list li").hover(function () {
        $(this).find('.new-pop-list').show();
     }, function () {
        $(this).find('.new-pop-list').hide();
     });

      /*公司下拉*/
      $(".head-nav .nav-right dl").hover(function () {
           $(this).find("dd").show();
           $(this).find("dt").addClass("open");
      }, function () {
           $(this).find("dd").hide();
          $(this).find("dt").removeClass("open");
      });

      /*底部微信*/
      $(".foot-contact .weixin").hover(function () {
           $(this).find("p").show();
      }, function () {
           $(this).find("p").hide();
      });
      $(".foot-contact .weibo").hover(function () {
           $(this).find("p").show();
      }, function () {
           $(this).find("p").hide();
      });

    /*返回顶部*/
    $(window).bind("resize scroll", function () {
        var scrollTop = $(this).scrollTop();
        if (scrollTop >200) {
            $('.back-top').css({visibility: 'visible'});
        } else {
            $('.back-top').css({visibility: 'hidden'});
        }
    });
    $(".back-top").click(function () {
        $('html,body').animate({scrollTop: '0px'}, 800);
    })

    /*右侧咨询*/
    $(".float-consult li").hover(function () {
        $(this).find(".consult").show();
    }, function () {
        $(this).find(".consult").hide();
    });
    /*$(".float-consult .item p").hover(function () {
        $(this).find("span").show();
    }, function () {
        $(this).find("span").hide();
    });*/
    $(".float-consult li").hover(function () {
        $(this).find(".service").show();
    }, function () {
        $(this).find(".service").hide();
    });
    $(".float-consult li").hover(function () {
        $(this).find(".ewm").show();
    }, function () {
        $(this).find(".ewm").hide();
    });

    /* 合作伙伴*/
      var boxObj = $(".partner-list");
        if(boxObj.data('bd')==1) return;
        var listObj = boxObj.find('.partner-bd');
        if (boxObj.length > 0 && listObj.length > 0) {
            listObj.find('.pt-list li').each(function (i) {
                listObj.find('.pt-list li').slice(i * 10, i * 10 + 10).wrapAll("<ul></ul>");
            });
            boxObj.slide({
                titCell: ".partner-hd  ul",
                mainCell: ".partner-bd .pt-list",
                autoPage: true,
                switchLoad: "data-sourceaddr",
                effect: "left",
                autoPlay: true,
                interTime: 4500
            });
        }



        
});

window.addServiceListener = function(callback){
  //增值服务通用js
  $('.addService>ul').on('click','li',function(){
    $('.addService>ul>li').removeClass('active');
    $(this).addClass('active');
    var val = $(this).data("value");
    $('.addService').find('input').val(val);

    callback && callback()
  }) 
}

window.front = window.front || {};

front.login = (function(){
  var show = function(success){
    LD.tip.open({
      content:$('#login-box').html(),
      title:false,
      resize:false,
      closeBtn:false,
      area:['520px','420px'],
      btn:false,
      success:function(layero,index){
        layero.find('#layer_submit').on('click',function(){
          var username = layero.find('#username').val();
          var password = layero.find('#password').val();
          var code = layero.find('#code').val();
          var ajaxurl = layero.find('#layer_submit').attr('data-ajaxurl');
          if(LD.util.empty(username))
          {
            layero.find('.errorInfo').html('请填写用户名');
            $('.errorInfo').show();
            setTimeout(function () {
              $('.errorInfo').hide();
            },600);
            return false;
          }
          if(LD.util.empty(password))
          {
            layero.find('.errorInfo').html('请填写密码');
            $('.errorInfo').show();
            setTimeout(function () {
              $('.errorInfo').hide();
            },600);
            return false;
          }
          LD.ajax.post(ajaxurl,{username:username,password:password,code:code},function(data){
            LD.tip.closeAll();
            new success(data);//
          },'',function(data){
            layero.find('.errorInfo').html(data.info);
            layero.find('#codeimg').attr("src",'/index/index/captcha?id='+Math.random());//更换验证码
            $('.errorInfo').show();
            setTimeout(function () {
              $('.errorInfo').hide();
            },600);
            if (data.status=='y'){
              LD.tip.closeAll();
            }
          });

        })
        return;
      },
      yes:function(index,layero){

      }
    })
  };
  return{
    show:show
  }
})()

 
